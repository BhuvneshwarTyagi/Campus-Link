import 'dart:ui';

import 'package:flutter/cupertino.dart';

Color Regbg=const Color.fromRGBO(12, 12, 12, 1);
Color Regcon= const Color.fromRGBO(40, 40, 40, 1);
Color RegText= const Color.fromRGBO(179, 179, 179, 1);
double heading = 25;